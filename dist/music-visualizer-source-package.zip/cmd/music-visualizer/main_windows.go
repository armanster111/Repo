//go:build windows

package main

import (
	"encoding/json"
	"fmt"
	"math"
	"os"
	"path/filepath"
	"runtime"
	"sort"
	"strings"
	"syscall"
	"time"
	"unicode/utf16"
	"unsafe"

	"github.com/armanster111/music-visualizer/internal/lyrics"
	"github.com/armanster111/music-visualizer/internal/metadata"
	"github.com/armanster111/music-visualizer/internal/visual"
)

const (
	appTitle = "Music Visualizer"
	fps      = 30
	barCount = 48

	csHRedraw = 0x0002
	csVRedraw = 0x0001

	cwUseDefault       = 0x80000000
	wsOverlappedWindow = 0x00cf0000

	swShowDefault   = 10
	swShowNormal    = 1
	swShowMaximized = 3

	wmDestroy     = 0x0002
	wmPaint       = 0x000f
	wmTimer       = 0x0113
	wmKeyDown     = 0x0100
	wmChar        = 0x0102
	wmCreate      = 0x0001
	wmMouseMove   = 0x0200
	wmLButtonDown = 0x0201
	wmLButtonUp   = 0x0202
	wmDropFiles   = 0x0233
	wmApp         = 0x8000
	wmMciNotify   = wmApp + 1

	mkLButton = 0x0001

	vkEscape         = 0x1b
	vkEnd            = 0x23
	vkHome           = 0x24
	vkLeft           = 0x25
	vkUp             = 0x26
	vkRight          = 0x27
	vkDown           = 0x28
	vkSpace          = 0x20
	vkF11            = 0x7a
	vkMediaNext      = 0xb0
	vkMediaPrev      = 0xb1
	vkMediaStop      = 0xb2
	vkMediaPlayPause = 0xb3

	idcArrow = 32512

	timerID = 1

	transparent = 1

	ofnPathMustExist = 0x00000800
	ofnFileMustExist = 0x00001000
	ofnExplorer      = 0x00080000

	mciNotifySuccess = 0x0001
	mciNotifyAborted = 0x0004

	mbIconError = 0x00000010
)

var (
	user32   = syscall.NewLazyDLL("user32.dll")
	gdi32    = syscall.NewLazyDLL("gdi32.dll")
	kernel32 = syscall.NewLazyDLL("kernel32.dll")
	comdlg32 = syscall.NewLazyDLL("comdlg32.dll")
	shell32  = syscall.NewLazyDLL("shell32.dll")
	winmm    = syscall.NewLazyDLL("winmm.dll")

	procBeginPaint          = user32.NewProc("BeginPaint")
	procCreateWindowExW     = user32.NewProc("CreateWindowExW")
	procDefWindowProcW      = user32.NewProc("DefWindowProcW")
	procDestroyWindow       = user32.NewProc("DestroyWindow")
	procDispatchMessageW    = user32.NewProc("DispatchMessageW")
	procEndPaint            = user32.NewProc("EndPaint")
	procFillRect            = user32.NewProc("FillRect")
	procGetClientRect       = user32.NewProc("GetClientRect")
	procGetMessageW         = user32.NewProc("GetMessageW")
	procInvalidateRect      = user32.NewProc("InvalidateRect")
	procLoadCursorW         = user32.NewProc("LoadCursorW")
	procMessageBoxW         = user32.NewProc("MessageBoxW")
	procPostQuitMessage     = user32.NewProc("PostQuitMessage")
	procRegisterClassExW    = user32.NewProc("RegisterClassExW")
	procReleaseCapture      = user32.NewProc("ReleaseCapture")
	procSetCapture          = user32.NewProc("SetCapture")
	procSetTimer            = user32.NewProc("SetTimer")
	procGetWindowRect       = user32.NewProc("GetWindowRect")
	procLoadIconW           = user32.NewProc("LoadIconW")
	procSetForegroundWindow = user32.NewProc("SetForegroundWindow")
	procSetWindowPos        = user32.NewProc("SetWindowPos")
	procShowWindow          = user32.NewProc("ShowWindow")
	procTranslateMessage    = user32.NewProc("TranslateMessage")
	procUpdateWindow        = user32.NewProc("UpdateWindow")

	procCreatePen        = gdi32.NewProc("CreatePen")
	procCreateSolidBrush = gdi32.NewProc("CreateSolidBrush")
	procDeleteObject     = gdi32.NewProc("DeleteObject")
	procEllipse          = gdi32.NewProc("Ellipse")
	procLineTo           = gdi32.NewProc("LineTo")
	procMoveToEx         = gdi32.NewProc("MoveToEx")
	procSelectObject     = gdi32.NewProc("SelectObject")
	procSetBkMode        = gdi32.NewProc("SetBkMode")
	procSetTextColor     = gdi32.NewProc("SetTextColor")
	procTextOutW         = gdi32.NewProc("TextOutW")

	procGetModuleHandleW   = kernel32.NewProc("GetModuleHandleW")
	procGetOpenFileNameW   = comdlg32.NewProc("GetOpenFileNameW")
	procDragAcceptFiles    = shell32.NewProc("DragAcceptFiles")
	procDragFinish         = shell32.NewProc("DragFinish")
	procDragQueryFileW     = shell32.NewProc("DragQueryFileW")
	procMCIGetErrorStringW = winmm.NewProc("mciGetErrorStringW")
	procMCISendStringW     = winmm.NewProc("mciSendStringW")
)

type visualMode int

const (
	modeClassic visualMode = iota
	modeMirror
	modeBlocks
	modeWave
	modeHalo
	modeSpectrum
	modeFire
	modeParticles
	modeTunnel
	modePlasma
	modeCount
)

type theme int

const (
	themeNeon theme = iota
	themeLava
	themeCyberpunk
	themeOcean
	themeCustomBase
	themeCount = themeCustomBase + 5
)

type repeatMode int

const (
	repeatOff repeatMode = iota
	repeatOne
	repeatAll
)

type settings struct {
	Mode               visualMode    `json:"mode"`
	Theme              theme         `json:"theme"`
	Volume             int           `json:"volume"`
	Muted              bool          `json:"muted"`
	DesktopInput       bool          `json:"desktop_input"`
	DesktopAuto        bool          `json:"desktop_auto"`
	DesktopSensitivity float64       `json:"desktop_sensitivity"`
	DesktopDevice      int           `json:"desktop_device"`
	Repeat             repeatMode    `json:"repeat"`
	Shuffle            bool          `json:"shuffle"`
	Recent             []string      `json:"recent"`
	Favorites          []string      `json:"favorites"`
	LibraryRoot        string        `json:"library_root"`
	SeenOnboarding     bool          `json:"seen_onboarding"`
	WindowX            int32         `json:"window_x"`
	WindowY            int32         `json:"window_y"`
	WindowW            int32         `json:"window_w"`
	WindowH            int32         `json:"window_h"`
	PlaybackSpeed      int           `json:"playback_speed"`
	EqBass             int           `json:"eq_bass"`
	EqMid              int           `json:"eq_mid"`
	EqTreble           int           `json:"eq_treble"`
	CustomThemes       []customTheme `json:"custom_themes"`
}

type track struct {
	Path     string
	Title    string
	Favorite bool
}

type button struct {
	label  string
	action string
	bounds rect
}

type appState struct {
	hwnd               uintptr
	filePath           string
	status             string
	frames             []visual.Frame
	currentBars        []float64
	ambientSeed        float64
	duration           time.Duration
	startedAt          time.Time
	playbackOffset     time.Duration
	dragPosition       time.Duration
	mode               visualMode
	theme              theme
	playlist           []track
	currentIndex       int
	recent             []string
	favorites          map[string]bool
	buttons            []button
	desktop            *desktopInput
	libraryRoot        string
	volume             int
	sleepMinutes       int
	sleepStartedAt     time.Time
	repeat             repeatMode
	seekLarge          bool
	shuffle            bool
	muted              bool
	desktopMode        bool
	fullscreen         bool
	mini               bool
	playing            bool
	paused             bool
	dragging           bool
	panel              panelView
	searchQuery        string
	visualOnly         bool
	seenOnboarding     bool
	windowX            int32
	windowY            int32
	windowW            int32
	windowH            int32
	playbackSpeed      int
	eqBass             int
	eqMid              int
	eqTreble           int
	eqFocus            int
	desktopSensitivity float64
	desktopAuto        bool
	desktopDevice      int
	customThemes       []customTheme
	meta               trackMeta
	lyricLines         []lyrics.Line
	artGrid            *metadata.ArtGrid
	energyHistory      []float64
	modeBlend          float64
	prevMode           visualMode
}

var app = &appState{
	status:             "Open or drag audio here. MP3/WAV playback, playlists, themes, and visualizers are ready.",
	currentIndex:       -1,
	theme:              themeNeon,
	volume:             800,
	playbackSpeed:      1000,
	desktopSensitivity: 1.0,
	favorites:          map[string]bool{},
	desktop:            newDesktopInput(),
}

type point struct {
	x int32
	y int32
}

type rect struct {
	left   int32
	top    int32
	right  int32
	bottom int32
}

type msg struct {
	hwnd    uintptr
	message uint32
	wParam  uintptr
	lParam  uintptr
	time    uint32
	pt      point
}

type paintStruct struct {
	hdc         uintptr
	erase       int32
	rcPaint     rect
	restore     int32
	incUpdate   int32
	rgbReserved [32]byte
}

type wndClassEx struct {
	size       uint32
	style      uint32
	wndProc    uintptr
	clsExtra   int32
	wndExtra   int32
	instance   uintptr
	icon       uintptr
	cursor     uintptr
	background uintptr
	menuName   *uint16
	className  *uint16
	iconSm     uintptr
}

type openFileName struct {
	structSize     uint32
	hwndOwner      uintptr
	instance       uintptr
	filter         *uint16
	customFilter   *uint16
	maxCustFilter  uint32
	filterIndex    uint32
	file           *uint16
	maxFile        uint32
	fileTitle      *uint16
	maxFileTitle   uint32
	initialDir     *uint16
	title          *uint16
	flags          uint32
	fileOffset     uint16
	fileExtension  uint16
	defaultExt     *uint16
	custData       uintptr
	hook           uintptr
	templateName   *uint16
	reserved       uintptr
	reservedFlags  uint32
	reservedFlags2 uint32
}

func main() {
	if err := run(); err != nil {
		showMessage(0, appTitle, err.Error(), mbIconError)
	}
}

func run() error {
	runtime.LockOSThread()
	app.loadSettings()

	instance, _, _ := procGetModuleHandleW.Call(0)
	className, _ := syscall.UTF16PtrFromString("MusicVisualizerWindow")
	title, _ := syscall.UTF16PtrFromString(appTitle)
	cursor, _, _ := procLoadCursorW.Call(0, idcArrow)

	wc := wndClassEx{
		size:      uint32(unsafe.Sizeof(wndClassEx{})),
		style:     csHRedraw | csVRedraw,
		wndProc:   syscall.NewCallback(wndProc),
		instance:  instance,
		cursor:    cursor,
		className: className,
	}
	if ret, _, err := procRegisterClassExW.Call(uintptr(unsafe.Pointer(&wc))); ret == 0 {
		return fmt.Errorf("register window class: %w", err)
	}

	hwnd, _, err := procCreateWindowExW.Call(
		0,
		uintptr(unsafe.Pointer(className)),
		uintptr(unsafe.Pointer(title)),
		wsOverlappedWindow,
		cwUseDefault,
		cwUseDefault,
		1000,
		640,
		0,
		0,
		instance,
		0,
	)
	if hwnd == 0 {
		return fmt.Errorf("create window: %w", err)
	}
	app.hwnd = hwnd
	procDragAcceptFiles.Call(hwnd, 1)
	app.restoreWindowBounds()
	app.initTray()
	app.showOnboardingIfNeeded()
	if app.desktop != nil {
		app.desktop.setSensitivity(app.desktopSensitivity)
		_ = app.desktop.setDeviceIndex(app.desktopDevice)
	}
	if app.desktopMode {
		_ = app.desktop.start()
	}

	procShowWindow.Call(hwnd, swShowDefault)
	procUpdateWindow.Call(hwnd)

	if len(os.Args) > 1 {
		app.openPath(os.Args[1])
	}

	var message msg
	for {
		ret, _, err := procGetMessageW.Call(uintptr(unsafe.Pointer(&message)), 0, 0, 0)
		if int32(ret) == -1 {
			return fmt.Errorf("get message: %w", err)
		}
		if ret == 0 {
			return nil
		}
		procTranslateMessage.Call(uintptr(unsafe.Pointer(&message)))
		procDispatchMessageW.Call(uintptr(unsafe.Pointer(&message)))
	}
}

func wndProc(hwnd uintptr, message uint32, wParam uintptr, lParam uintptr) uintptr {
	switch message {
	case wmCreate:
		procSetTimer.Call(hwnd, timerID, 1000/fps, 0)
		return 0
	case wmTimer:
		app.tickSleepTimer()
		app.maybeAutoDesktop()
		if app.modeBlend < 1 {
			app.modeBlend += 0.1
		}
		procInvalidateRect.Call(hwnd, 0, 0)
		return 0
	case wmKeyDown:
		switch wParam {
		case vkEscape:
			procDestroyWindow.Call(hwnd)
		case vkEnd:
			app.nextTrack()
		case vkHome:
			app.seekTo(0, app.playing)
		case vkLeft:
			app.seekBy(-app.seekStep())
		case vkRight:
			app.seekBy(app.seekStep())
		case vkUp:
			app.changeVolume(50)
		case vkDown:
			app.changeVolume(-50)
		case vkSpace:
			app.togglePlay()
		case vkF11:
			app.toggleFullscreen()
		case vkMediaNext:
			app.nextTrack()
		case vkMediaPrev:
			app.previousTrack()
		case vkMediaStop:
			if app.playing {
				app.togglePlay()
			}
		case vkMediaPlayPause:
			app.togglePlay()
		case uintptr('B'):
			app.previousTrack()
		case uintptr('C'):
			app.exportSnapshot()
		case uintptr('D'):
			app.loadCurrentFolder()
		case uintptr('E'):
			app.focusNextEQBand()
		case uintptr('F'):
			app.toggleFavorite()
		case uintptr('G'):
			app.nextTheme()
		case uintptr('H'):
			app.saveCustomTheme()
		case uintptr('I'):
			app.toggleDesktopInput()
		case uintptr('J'):
			app.cyclePlaybackSpeed()
		case uintptr('K'):
			app.cycleEQBand()
		case uintptr('L'):
			app.toggleFullscreen()
		case uintptr('M'):
			app.toggleMute()
		case uintptr('N'):
			app.nextTrack()
		case uintptr('O'):
			if path, ok := openWAVDialog(hwnd); ok {
				app.openPath(path)
			}
		case uintptr('P'):
			app.toggleShuffle()
		case uintptr('Q'):
			app.cycleRepeat()
		case uintptr('R'):
			app.restart()
		case uintptr('S'):
			app.cycleSleepTimer()
		case uintptr('T'):
			app.seekLarge = !app.seekLarge
			app.updateStatus()
			invalidate()
		case uintptr('U'):
			app.showRecentView()
		case uintptr('V'):
			app.cycleMode()
		case uintptr('W'):
			app.cycleDesktopDevice()
		case uintptr('X'):
			app.toggleMini()
		case uintptr('Y'):
			app.showFavoritesView()
		case uintptr('Z'):
			app.toggleVisualOnly()
		case uintptr('A'):
			app.toggleDesktopAuto()
		case uintptr('/'):
			app.showSearchView()
		case uintptr(']'):
			app.cycleDesktopSensitivity()
		}
		return 0
	case wmChar:
		if app.panel == viewSearch {
			app.appendSearchChar(rune(wParam))
		}
		return 0
	case wmTrayIcon:
		app.handleTrayMessage(lParam)
		return 0
	case wmMciNotify:
		if wParam == mciNotifySuccess {
			app.handleTrackEnded()
		}
		return 0
	case wmDropFiles:
		app.handleDrop(wParam)
		return 0
	case wmLButtonDown:
		x, y := mousePoint(lParam)
		if app.handleButtonClick(x, y) {
			return 0
		}
		if app.seekFromPoint(x, y) {
			app.dragging = true
			procSetCapture.Call(hwnd)
		}
		return 0
	case wmMouseMove:
		if app.dragging && wParam&mkLButton != 0 {
			x, y := mousePoint(lParam)
			app.seekFromPoint(x, y)
		}
		return 0
	case wmLButtonUp:
		if app.dragging {
			x, y := mousePoint(lParam)
			app.seekFromPoint(x, y)
			app.dragging = false
			procReleaseCapture.Call()
		}
		return 0
	case wmPaint:
		draw(hwnd)
		return 0
	case wmDestroy:
		app.saveWindowBounds()
		app.removeTray()
		app.stopDesktopInput()
		closeTrack()
		procPostQuitMessage.Call(0)
		return 0
	default:
		ret, _, _ := procDefWindowProcW.Call(hwnd, uintptr(message), wParam, lParam)
		return ret
	}
}

func (s *appState) openPath(path string) {
	info, err := os.Stat(path)
	if err != nil {
		s.status = "Could not open file: " + err.Error()
		invalidate()
		return
	}
	if info.IsDir() {
		s.openPlaylist(collectAudioFiles(path), 0)
		return
	}
	if !isAudioFile(path) {
		s.status = "Unsupported file. Try WAV, MP3, WMA, MID, AIFF, AU, or SND."
		invalidate()
		return
	}

	playlist := collectAudioFiles(filepath.Dir(path))
	index := indexOfPath(playlist, path)
	if index < 0 {
		playlist = []track{makeTrack(path, s.favorites)}
		index = 0
	}
	s.openPlaylist(playlist, index)
}

func (s *appState) openPlaylist(playlist []track, index int) {
	if len(playlist) == 0 {
		s.status = "No supported audio files found."
		invalidate()
		return
	}
	if index < 0 || index >= len(playlist) {
		index = 0
	}
	s.playlist = playlist
	s.currentIndex = index
	s.libraryRoot = filepath.Dir(playlist[index].Path)
	s.loadCurrentTrack(true)
}

func (s *appState) loadCurrentFolder() {
	if s.filePath == "" {
		s.status = "Open a song first, then press D to load its folder as a playlist."
		invalidate()
		return
	}
	s.openPlaylist(collectAudioFiles(filepath.Dir(s.filePath)), indexOfPath(collectAudioFiles(filepath.Dir(s.filePath)), s.filePath))
}

func (s *appState) loadCurrentTrack(play bool) {
	if s.currentIndex < 0 || s.currentIndex >= len(s.playlist) {
		return
	}
	path := s.playlist[s.currentIndex].Path
	if err := openTrack(path); err != nil {
		s.status = "Windows could not open this audio file: " + err.Error()
		s.frames = nil
		s.playing = false
		closeTrack()
		invalidate()
		return
	}

	duration, err := trackDuration()
	if err != nil || duration <= 0 {
		duration = time.Minute
	}

	s.frames = nil
	s.currentBars = nil
	s.ambientSeed = float64(hashPath(path)%1000) / 100
	s.loadTrackMedia(path)
	if frames, dur := s.buildFramesForPath(path); len(frames) > 0 {
		s.frames = frames
		if dur > 0 {
			duration = dur
		}
	}

	s.filePath = path
	s.duration = duration
	s.playbackOffset = 0
	s.dragPosition = 0
	s.paused = !play
	s.addRecent(path)
	s.applyVolume()
	s.applyEqualizer()
	s.saveSettings()
	if play {
		s.restart()
	} else {
		s.updateStatus()
		invalidate()
	}
}

func (s *appState) restart() {
	if s.filePath == "" {
		return
	}
	s.seekTo(0, true)
}

func (s *appState) togglePlay() {
	if s.filePath == "" {
		return
	}
	if s.playing {
		pos := s.position()
		if err := pauseTrack(); err != nil {
			s.status = "Pause failed: " + err.Error()
			invalidate()
			return
		}
		s.playbackOffset = pos
		s.playing = false
		s.paused = true
		s.updateStatus()
		return
	}
	if s.position() >= s.duration {
		s.playbackOffset = 0
	}
	s.seekTo(s.playbackOffset, true)
}

func (s *appState) nextTrack() {
	if len(s.playlist) == 0 {
		return
	}
	if s.shuffle && len(s.playlist) > 1 {
		s.currentIndex = (s.currentIndex + 3) % len(s.playlist)
	} else {
		s.currentIndex++
		if s.currentIndex >= len(s.playlist) {
			if s.repeat == repeatAll {
				s.currentIndex = 0
			} else {
				s.currentIndex = len(s.playlist) - 1
				s.playing = false
				s.paused = false
				s.updateStatus()
				invalidate()
				return
			}
		}
	}
	s.loadCurrentTrack(true)
}

func (s *appState) previousTrack() {
	if len(s.playlist) == 0 {
		return
	}
	if s.position() > 3*time.Second {
		s.restart()
		return
	}
	s.currentIndex--
	if s.currentIndex < 0 {
		if s.repeat == repeatAll {
			s.currentIndex = len(s.playlist) - 1
		} else {
			s.currentIndex = 0
		}
	}
	s.loadCurrentTrack(true)
}

func (s *appState) handleTrackEnded() {
	if s.repeat == repeatOne {
		s.restart()
		return
	}
	s.nextTrack()
}

func (s *appState) toggleShuffle() {
	s.shuffle = !s.shuffle
	s.updateStatus()
	s.saveSettings()
	invalidate()
}

func (s *appState) cycleRepeat() {
	s.repeat = (s.repeat + 1) % 3
	s.updateStatus()
	s.saveSettings()
	invalidate()
}

func (s *appState) toggleFavorite() {
	if s.filePath == "" {
		return
	}
	clean := filepath.Clean(s.filePath)
	s.favorites[clean] = !s.favorites[clean]
	if s.currentIndex >= 0 && s.currentIndex < len(s.playlist) {
		s.playlist[s.currentIndex].Favorite = s.favorites[clean]
	}
	s.updateStatus()
	s.saveSettings()
	invalidate()
}

func (s *appState) exportSnapshot() {
	bars := s.targetBars()
	if len(bars) == 0 {
		s.status = "No visualizer snapshot to export yet."
		invalidate()
		return
	}
	home, err := os.UserHomeDir()
	if err != nil {
		home = "."
	}
	dir := filepath.Join(home, "Desktop")
	if info, err := os.Stat(dir); err != nil || !info.IsDir() {
		dir = home
	}
	name := fmt.Sprintf("music-visualizer-%s.ppm", time.Now().Format("20060102-150405"))
	path := filepath.Join(dir, name)
	if err := writeSnapshot(path, bars, s.mode, s.theme); err != nil {
		s.status = "Snapshot failed: " + err.Error()
	} else {
		s.status = "Saved snapshot: " + path
	}
	invalidate()
}

func (s *appState) changeVolume(delta int) {
	s.volume = clampInt(s.volume+delta, 0, 1000)
	s.muted = false
	s.applyVolume()
	s.updateStatus()
	s.saveSettings()
	invalidate()
}

func (s *appState) toggleMute() {
	s.muted = !s.muted
	s.applyVolume()
	s.updateStatus()
	s.saveSettings()
	invalidate()
}

func (s *appState) toggleDesktopInput() {
	if s.desktop == nil {
		s.desktop = newDesktopInput()
	}
	if s.desktopMode {
		s.stopDesktopInput()
		s.status = "Desktop audio input off. Visualizer is back on player audio."
	} else {
		if err := s.desktop.start(); err != nil {
			s.status = "Desktop audio input failed: " + err.Error()
			invalidate()
			return
		}
		s.desktopMode = true
		s.status = "Desktop audio input on. Play anything on Windows and the visualizer will react."
	}
	s.saveSettings()
	invalidate()
}

func (s *appState) stopDesktopInput() {
	if s.desktop != nil {
		s.desktop.stopCapture()
	}
	s.desktopMode = false
	s.saveSettings()
	invalidate()
}

func (s *appState) applyVolume() {
	volume := s.volume
	if s.muted {
		volume = 0
	}
	_ = mciSend(fmt.Sprintf("setaudio musicvisualizer_track volume to %d", volume))
}

func (s *appState) cycleSleepTimer() {
	switch s.sleepMinutes {
	case 0:
		s.sleepMinutes = 15
	case 15:
		s.sleepMinutes = 30
	case 30:
		s.sleepMinutes = 60
	default:
		s.sleepMinutes = 0
	}
	s.sleepStartedAt = time.Now()
	s.updateStatus()
	invalidate()
}

func (s *appState) tickSleepTimer() {
	if s.sleepMinutes == 0 || s.sleepStartedAt.IsZero() {
		return
	}
	if time.Since(s.sleepStartedAt) >= time.Duration(s.sleepMinutes)*time.Minute {
		if s.playing {
			s.togglePlay()
		}
		s.sleepMinutes = 0
		s.status = "Sleep timer paused playback."
	}
}

func (s *appState) toggleMini() {
	s.mini = !s.mini
	s.updateStatus()
	invalidate()
}

func (s *appState) toggleFullscreen() {
	s.fullscreen = !s.fullscreen
	if s.fullscreen {
		procShowWindow.Call(s.hwnd, swShowMaximized)
	} else {
		procShowWindow.Call(s.hwnd, swShowNormal)
	}
	s.updateStatus()
	invalidate()
}

func (s *appState) seekBy(delta time.Duration) {
	if s.filePath == "" {
		return
	}
	s.seekTo(s.position()+delta, s.playing)
}

func (s *appState) seekTo(pos time.Duration, play bool) {
	if s.filePath == "" {
		return
	}
	pos = clampDuration(pos, 0, s.duration)
	s.playbackOffset = pos
	s.dragPosition = pos
	if play {
		if err := playTrackFrom(pos); err != nil {
			s.status = "Play failed: " + err.Error()
			s.playing = false
			s.paused = false
			invalidate()
			return
		}
		s.startedAt = time.Now()
		s.playing = true
		s.paused = false
		s.applyPlaybackSpeed()
	} else if !s.paused {
		_ = stopTrack()
	}
	s.updateStatus()
}

func (s *appState) cycleMode() {
	s.prevMode = s.mode
	s.modeBlend = 0
	s.mode = (s.mode + 1) % modeCount
	s.updateStatus()
	s.saveSettings()
	invalidate()
}

func (s *appState) nextTheme() {
	maxTheme := themeOcean + 1
	if len(s.customThemes) > 0 {
		maxTheme = themeCustomBase + theme(len(s.customThemes))
	}
	s.theme = (s.theme + 1) % maxTheme
	s.updateStatus()
	s.saveSettings()
	invalidate()
}

func (s *appState) cycleEqualizer() {
	s.focusNextEQBand()
}

func (s *appState) seekStep() time.Duration {
	if s.seekLarge {
		return 30 * time.Second
	}
	return 10 * time.Second
}

func (s *appState) position() time.Duration {
	if s.dragging {
		return s.dragPosition
	}
	if !s.playing {
		return clampDuration(s.playbackOffset, 0, s.duration)
	}
	return clampDuration(s.playbackOffset+time.Since(s.startedAt), 0, s.duration)
}

func (s *appState) progress() float64 {
	if s.duration <= 0 {
		return 0
	}
	return clamp(float64(s.position())/float64(s.duration), 0, 1)
}

func (s *appState) updateStatus() {
	if s.filePath == "" {
		s.status = fmt.Sprintf("Open or drag audio. Input:%s | Mode:%s | Theme:%s | Volume:%d%%", s.inputName(), modeName(s.mode), themeName(s.theme), s.volume/10)
		return
	}
	state := "Playing"
	if s.paused {
		state = "Paused"
	} else if !s.playing {
		state = "Ready"
	}
	fav := ""
	if s.favorites[filepath.Clean(s.filePath)] {
		fav = " *Favorite"
	}
	s.status = fmt.Sprintf("%s %s%s  %s/%s  Input:%s  Mode:%s  Theme:%s  Vol:%d%%  Shuffle:%t  Repeat:%s  Sleep:%s",
		state,
		filepath.Base(s.filePath),
		fav,
		durationText(s.position()),
		durationText(s.duration),
		s.inputName(),
		modeName(s.mode),
		themeName(s.theme),
		s.volume/10,
		s.shuffle,
		repeatName(s.repeat),
		sleepText(s.sleepMinutes),
	)
}

func (s *appState) inputName() string {
	if s.desktopMode {
		if s.desktop != nil {
			if errText := s.desktop.errText(); errText != "" {
				return "Desktop error"
			}
		}
		return "Desktop"
	}
	return "Player"
}

func (s *appState) targetBars() []float64 {
	if s.desktopMode && s.desktop != nil && s.desktop.isActive() {
		if bars := s.desktop.snapshot(); len(bars) > 0 {
			return bars
		}
	}
	if len(s.frames) == 0 {
		return s.ambientBars()
	}
	pos := s.position()
	if s.playing && pos >= s.duration {
		s.playing = false
		s.playbackOffset = s.duration
		_ = stopTrack()
		s.updateStatus()
		return s.frames[len(s.frames)-1].Bars
	}

	index := int(pos.Seconds() * fps)
	if index < 0 {
		index = 0
	}
	if index >= len(s.frames) {
		index = len(s.frames) - 1
	}
	return s.frames[index].Bars
}

func (s *appState) ambientBars() []float64 {
	bars := make([]float64, barCount)
	pos := s.position().Seconds()
	if !s.playing {
		pos = float64(time.Now().UnixMilli()) / 1000
	}
	pulse := 0.5 + math.Sin(pos*2.4+s.ambientSeed)*0.5
	for i := range bars {
		x := float64(i)
		low := math.Sin(pos*3.1+s.ambientSeed+x*0.17)*0.5 + 0.5
		mid := math.Sin(pos*5.7+s.ambientSeed*0.6+x*0.31)*0.5 + 0.5
		high := math.Sin(pos*8.3+s.ambientSeed*1.3+x*0.73)*0.5 + 0.5
		shape := math.Sin(float64(i) / float64(barCount) * math.Pi)
		bars[i] = clamp((low*0.45+mid*0.35+high*0.20)*(0.35+shape*0.65)+pulse*0.18, 0.04, 1)
	}
	return bars
}

func openWAVDialog(hwnd uintptr) (string, bool) {
	var fileBuffer [4096]uint16
	filter := utf16WithNULs("Audio files\x00*.wav;*.mp3;*.wma;*.mid;*.midi;*.aiff;*.aif;*.au;*.snd\x00WAV files (*.wav)\x00*.wav\x00MP3 files (*.mp3)\x00*.mp3\x00All files (*.*)\x00*.*\x00\x00")
	title, _ := syscall.UTF16PtrFromString("Open an audio file")

	ofn := openFileName{
		structSize: uint32(unsafe.Sizeof(openFileName{})),
		hwndOwner:  hwnd,
		filter:     &filter[0],
		file:       &fileBuffer[0],
		maxFile:    uint32(len(fileBuffer)),
		title:      title,
		flags:      ofnExplorer | ofnPathMustExist | ofnFileMustExist,
	}

	ret, _, _ := procGetOpenFileNameW.Call(uintptr(unsafe.Pointer(&ofn)))
	if ret == 0 {
		return "", false
	}
	return syscall.UTF16ToString(fileBuffer[:]), true
}

func draw(hwnd uintptr) {
	var ps paintStruct
	hdc, _, _ := procBeginPaint.Call(hwnd, uintptr(unsafe.Pointer(&ps)))
	defer procEndPaint.Call(hwnd, uintptr(unsafe.Pointer(&ps)))

	var bounds rect
	procGetClientRect.Call(hwnd, uintptr(unsafe.Pointer(&bounds)))

	width := bounds.right - bounds.left
	height := bounds.bottom - bounds.top
	palette := currentPalette()
	fill(hdc, bounds, palette.background)

	procSetBkMode.Call(hdc, transparent)
	procSetTextColor.Call(hdc, palette.text)
	textOut(hdc, 28, 24, appTitle+" Pro")
	if !app.mini && !app.visualOnly {
		procSetTextColor.Call(hdc, palette.dim)
		metaLine := app.status
		if app.meta.Title != "" {
			metaLine = fmt.Sprintf("%s — %s", app.meta.Title, app.meta.Artist)
			if line := app.currentLyric(); line != "" {
				metaLine += " | " + line
			}
		}
		textOut(hdc, 28, 52, metaLine)
		textOut(hdc, 28, 68, app.status)
		textOut(hdc, 28, height-30, "O open | I desktop | V viz | G theme | U recent | Y favorites | / search | Z visual-only | J speed | K EQ")
		drawButtons(hdc, width, height)
		drawPlaylist(hdc, width, height)
	}
	if !app.visualOnly {
		drawProgress(hdc, width, height, palette)
	}

	bars := app.targetBars()
	beat := app.beatMultiplier(bars)
	for i := range bars {
		bars[i] = math.Min(1, bars[i]*beat)
	}
	if len(app.currentBars) != len(bars) {
		app.currentBars = make([]float64, len(bars))
	}

	top := int32(112)
	bottom := height - 104
	if app.mini || app.visualOnly {
		top = 28
		bottom = height - 28
	}
	if bottom <= top {
		return
	}

	visualBounds := rect{left: 28, top: top, right: width - 28, bottom: bottom}
	if app.artGrid != nil && !app.visualOnly {
		drawAlbumArtBackground(hdc, visualBounds, app.artGrid)
	}
	smooth := 0.35
	if app.modeBlend < 1 {
		smooth = 0.18
	}
	for i, target := range bars {
		app.currentBars[i] += (target - app.currentBars[i]) * smooth
	}
	drawVisualization(hdc, visualBounds, app.currentBars, app.mode)
}

func drawVisualization(hdc uintptr, bounds rect, bars []float64, mode visualMode) {
	switch mode {
	case modeMirror:
		drawMirrorBars(hdc, bounds, bars)
	case modeBlocks:
		drawBlockStack(hdc, bounds, bars)
	case modeWave:
		drawWaveLine(hdc, bounds, bars)
	case modeHalo:
		drawHalo(hdc, bounds, bars)
	case modeSpectrum:
		drawSpectrum(hdc, bounds, bars)
	case modeFire:
		drawFire(hdc, bounds, bars)
	case modeParticles:
		drawParticles(hdc, bounds, bars)
	case modeTunnel:
		drawTunnel(hdc, bounds, bars)
	case modePlasma:
		drawPlasma(hdc, bounds, bars)
	default:
		drawClassicBars(hdc, bounds, bars)
	}
}

func drawClassicBars(hdc uintptr, bounds rect, bars []float64) {
	if len(bars) == 0 {
		return
	}
	margin := int32(0)
	gap := int32(5)
	width := bounds.right - bounds.left
	usableHeight := bounds.bottom - bounds.top
	barWidth := (width - margin*2 - gap*int32(len(bars)-1)) / int32(len(bars))
	if barWidth < 2 {
		barWidth = 2
		gap = 2
	}
	for i, target := range bars {
		value := math.Pow(clamp(target, 0, 1), 0.75)
		barHeight := int32(value * float64(usableHeight))
		left := bounds.left + margin + int32(i)*(barWidth+gap)
		right := left + barWidth
		color := bandGradientColor(i, len(bars), bars)
		fill(hdc, rect{left: left, top: bounds.bottom - barHeight, right: right, bottom: bounds.bottom}, color)
	}
}

func drawMirrorBars(hdc uintptr, bounds rect, bars []float64) {
	if len(bars) == 0 {
		return
	}
	gap := int32(5)
	width := bounds.right - bounds.left
	middle := bounds.top + (bounds.bottom-bounds.top)/2
	halfHeight := (bounds.bottom - bounds.top) / 2
	barWidth := (width - gap*int32(len(bars)-1)) / int32(len(bars))
	if barWidth < 2 {
		barWidth = 2
		gap = 2
	}
	for i, target := range bars {
		value := math.Pow(clamp(target, 0, 1), 0.8)
		barHeight := int32(value * float64(halfHeight))
		left := bounds.left + int32(i)*(barWidth+gap)
		right := left + barWidth
		color := gradientColor(i, len(bars), 230)
		fill(hdc, rect{left: left, top: middle - barHeight, right: right, bottom: middle}, color)
		fill(hdc, rect{left: left, top: middle + 2, right: right, bottom: middle + barHeight + 2}, dimColor(color, 0.55))
	}
	line(hdc, bounds.left, middle, bounds.right, middle, rgb(34, 44, 70), 1)
}

func drawBlockStack(hdc uintptr, bounds rect, bars []float64) {
	if len(bars) == 0 {
		return
	}
	const blocks = 12
	gap := int32(4)
	width := bounds.right - bounds.left
	barWidth := (width - gap*int32(len(bars)-1)) / int32(len(bars))
	blockGap := int32(4)
	blockHeight := (bounds.bottom - bounds.top - blockGap*(blocks-1)) / blocks
	if blockHeight < 3 {
		blockHeight = 3
		blockGap = 2
	}
	for i, target := range bars {
		filled := int(math.Ceil(clamp(target, 0, 1) * blocks))
		left := bounds.left + int32(i)*(barWidth+gap)
		for block := 0; block < blocks; block++ {
			top := bounds.bottom - int32(block+1)*(blockHeight+blockGap)
			if block < filled {
				fill(hdc, rect{left: left, top: top, right: left + barWidth, bottom: top + blockHeight}, gradientColor(i+block, len(bars)+blocks, 255))
			} else if block%3 == 0 {
				fill(hdc, rect{left: left, top: top, right: left + barWidth, bottom: top + blockHeight}, rgb(20, 25, 43))
			}
		}
	}
}

func drawWaveLine(hdc uintptr, bounds rect, bars []float64) {
	if len(bars) == 0 {
		return
	}
	middle := bounds.top + (bounds.bottom-bounds.top)/2
	width := bounds.right - bounds.left
	line(hdc, bounds.left, middle, bounds.right, middle, rgb(30, 40, 64), 1)
	for layer := 0; layer < 3; layer++ {
		color := []uintptr{rgb(80, 220, 255), rgb(185, 90, 255), rgb(255, 90, 170)}[layer]
		penWidth := int32(4 - layer)
		pen, _, _ := procCreatePen.Call(0, uintptr(penWidth), color)
		if pen == 0 {
			continue
		}
		old, _, _ := procSelectObject.Call(hdc, pen)
		for i, target := range bars {
			x := bounds.left + int32(i)*width/int32(max(1, len(bars)-1))
			phase := math.Sin(float64(i+layer*5) * 0.45)
			y := middle - int32((target*0.75+phase*0.08)*float64(bounds.bottom-bounds.top)/2)
			if i == 0 {
				procMoveToEx.Call(hdc, uintptr(x), uintptr(y), 0)
			} else {
				procLineTo.Call(hdc, uintptr(x), uintptr(y))
			}
		}
		procSelectObject.Call(hdc, old)
		procDeleteObject.Call(pen)
	}
}

func drawHalo(hdc uintptr, bounds rect, bars []float64) {
	if len(bars) == 0 {
		return
	}
	cx := bounds.left + (bounds.right-bounds.left)/2
	cy := bounds.top + (bounds.bottom-bounds.top)/2
	maxRadius := min(bounds.right-bounds.left, bounds.bottom-bounds.top) / 2
	for ring := 3; ring >= 1; ring-- {
		radius := maxRadius * int32(ring) / 4
		ellipse(hdc, cx-radius, cy-radius, cx+radius, cy+radius, rgb(22+byte(ring*12), 28+byte(ring*12), 48+byte(ring*14)))
	}
	for i, target := range bars {
		angle := float64(i)/float64(len(bars))*math.Pi*2 - math.Pi/2
		inner := float64(maxRadius) * 0.42
		outer := inner + math.Pow(clamp(target, 0, 1), 0.65)*float64(maxRadius)*0.56
		x1 := cx + int32(math.Cos(angle)*inner)
		y1 := cy + int32(math.Sin(angle)*inner)
		x2 := cx + int32(math.Cos(angle)*outer)
		y2 := cy + int32(math.Sin(angle)*outer)
		line(hdc, x1, y1, x2, y2, gradientColor(i, len(bars), 255), 3)
	}
}

func drawSpectrum(hdc uintptr, bounds rect, bars []float64) {
	if len(bars) == 0 {
		return
	}
	bands := []uintptr{rgb(66, 220, 255), rgb(120, 255, 120), rgb(255, 220, 70), rgb(255, 88, 88)}
	gap := int32(4)
	width := bounds.right - bounds.left
	barWidth := (width - gap*int32(len(bars)-1)) / int32(len(bars))
	for i, target := range bars {
		value := math.Pow(clamp(target, 0, 1), 0.7)
		barHeight := int32(value * float64(bounds.bottom-bounds.top))
		left := bounds.left + int32(i)*(barWidth+gap)
		band := i * len(bands) / len(bars)
		fill(hdc, rect{left: left, top: bounds.bottom - barHeight, right: left + barWidth, bottom: bounds.bottom}, bands[band])
	}
}

func drawFire(hdc uintptr, bounds rect, bars []float64) {
	if len(bars) == 0 {
		return
	}
	const layers = 9
	width := bounds.right - bounds.left
	cellW := max(int32(3), width/int32(len(bars)))
	for i, target := range bars {
		flame := int(clamp(target, 0, 1) * layers)
		for layer := 0; layer < layers; layer++ {
			left := bounds.left + int32(i)*cellW
			bottom := bounds.bottom - int32(layer)*(bounds.bottom-bounds.top)/layers
			top := bottom - (bounds.bottom-bounds.top)/layers + 2
			color := rgb(byte(80+layer*19), byte(20+layer*18), byte(max(0, 80-layer*10)))
			if layer < flame {
				fill(hdc, rect{left: left, top: top, right: left + cellW - 1, bottom: bottom}, color)
			}
		}
	}
}

func drawParticles(hdc uintptr, bounds rect, bars []float64) {
	if len(bars) == 0 {
		return
	}
	cx := bounds.left + (bounds.right-bounds.left)/2
	cy := bounds.top + (bounds.bottom-bounds.top)/2
	now := float64(time.Now().UnixMilli()) / 700
	for i, target := range bars {
		angle := float64(i)/float64(len(bars))*math.Pi*2 + now*0.18
		radius := (0.15 + target*0.82) * float64(min(bounds.right-bounds.left, bounds.bottom-bounds.top)) / 2
		x := cx + int32(math.Cos(angle)*radius)
		y := cy + int32(math.Sin(angle)*radius)
		size := int32(3 + target*10)
		ellipse(hdc, x-size, y-size, x+size, y+size, gradientColor(i, len(bars), 255))
	}
}

func drawTunnel(hdc uintptr, bounds rect, bars []float64) {
	if len(bars) == 0 {
		return
	}
	cx := bounds.left + (bounds.right-bounds.left)/2
	cy := bounds.top + (bounds.bottom-bounds.top)/2
	maxR := min(bounds.right-bounds.left, bounds.bottom-bounds.top) / 2
	now := float64(time.Now().UnixMilli()) / 800
	for ring := 9; ring >= 1; ring-- {
		idx := ring * len(bars) / 10
		energy := bars[min(idx, len(bars)-1)]
		radius := int32(float64(maxR) * (float64(ring)/10 + energy*0.06))
		offset := int32(math.Sin(now+float64(ring)) * energy * 18)
		line(hdc, cx-radius+offset, cy-radius, cx+radius, cy-radius+offset, gradientColor(ring, 10, 255), 2)
		line(hdc, cx+radius, cy-radius+offset, cx+radius-offset, cy+radius, gradientColor(ring, 10, 255), 2)
		line(hdc, cx+radius-offset, cy+radius, cx-radius, cy+radius-offset, gradientColor(ring, 10, 255), 2)
		line(hdc, cx-radius, cy+radius-offset, cx-radius+offset, cy-radius, gradientColor(ring, 10, 255), 2)
	}
}

func drawPlasma(hdc uintptr, bounds rect, bars []float64) {
	if len(bars) == 0 {
		return
	}
	cols := 18
	rows := 10
	cellW := max(int32(3), (bounds.right-bounds.left)/int32(cols))
	cellH := max(int32(3), (bounds.bottom-bounds.top)/int32(rows))
	now := float64(time.Now().UnixMilli()) / 520
	for y := 0; y < rows; y++ {
		for x := 0; x < cols; x++ {
			idx := (x + y*cols) % len(bars)
			energy := bars[idx]
			wave := math.Sin(float64(x)*0.9+now) + math.Cos(float64(y)*1.2-now*0.8)
			level := clamp((wave+2)/4*0.55+energy*0.45, 0, 1)
			left := bounds.left + int32(x)*cellW
			top := bounds.top + int32(y)*cellH
			fill(hdc, rect{left: left, top: top, right: left + cellW - 2, bottom: top + cellH - 2}, rgb(byte(45+level*160), byte(40+level*80), byte(110+level*140)))
		}
	}
}

func drawProgress(hdc uintptr, width, height int32, palette palette) {
	bar := progressRect(width, height)
	fill(hdc, bar, palette.panel)
	progress := app.progress()
	fill(hdc, rect{left: bar.left, top: bar.top, right: bar.left + int32(progress*float64(bar.right-bar.left)), bottom: bar.bottom}, palette.accent)
	knobX := bar.left + int32(progress*float64(bar.right-bar.left))
	fill(hdc, rect{left: knobX - 4, top: bar.top - 5, right: knobX + 4, bottom: bar.bottom + 5}, palette.text)
	if !app.mini {
		procSetTextColor.Call(hdc, palette.dim)
		textOut(hdc, bar.left, bar.bottom+14, "Click/drag to seek. Drop audio files anywhere.")
	}
}

func drawButtons(hdc uintptr, width, height int32) {
	labels := []button{
		{label: "Open", action: "open"},
		{label: "Prev", action: "prev"},
		{label: playLabel(), action: "play"},
		{label: "Next", action: "next"},
		{label: "Viz", action: "viz"},
		{label: inputLabel(), action: "input"},
		{label: "Theme", action: "theme"},
		{label: "Shuffle", action: "shuffle"},
		{label: "Repeat", action: "repeat"},
		{label: "Fav", action: "favorite"},
		{label: "Mute", action: "mute"},
		{label: "Speed", action: "speed"},
		{label: "Recent", action: "recent"},
		{label: "Favs", action: "favs"},
	}
	app.buttons = app.buttons[:0]
	palette := currentPalette()
	left := int32(28)
	top := int32(74)
	for i := range labels {
		w := int32(78)
		b := labels[i]
		b.bounds = rect{left: left, top: top, right: left + w, bottom: top + 28}
		app.buttons = append(app.buttons, b)
		fill(hdc, b.bounds, palette.panel)
		line(hdc, b.bounds.left, b.bounds.bottom, b.bounds.right, b.bounds.bottom, palette.accent, 2)
		procSetTextColor.Call(hdc, palette.text)
		textOut(hdc, b.bounds.left+10, b.bounds.top+7, b.label)
		left += w + 8
		if left+80 > width-28 {
			break
		}
	}
}

func drawPlaylist(hdc uintptr, width, height int32) {
	list := app.filteredPlaylist()
	if len(list) == 0 && app.panel == viewQueue {
		return
	}
	palette := currentPalette()
	left := width - 292
	if left < width/2 {
		return
	}
	top := int32(128)
	fill(hdc, rect{left: left, top: top, right: width - 28, bottom: height - 104}, dimColor(palette.panel, 0.75))
	procSetTextColor.Call(hdc, palette.text)
	textOut(hdc, left+12, top+10, fmt.Sprintf("%s (%d)", app.panelTitle(), len(list)))
	procSetTextColor.Call(hdc, palette.dim)
	for row := 0; row < 8 && row < len(list); row++ {
		t := list[row]
		procSetTextColor.Call(hdc, palette.dim)
		fav := ""
		if t.Favorite {
			fav = "* "
		}
		textOut(hdc, left+12, top+38+int32(row*24), truncate(fav+t.Title, 34))
	}
}

func (s *appState) handleButtonClick(x, y int32) bool {
	for _, b := range s.buttons {
		if pointInRect(x, y, b.bounds) {
			switch b.action {
			case "open":
				if path, ok := openWAVDialog(s.hwnd); ok {
					s.openPath(path)
				}
			case "prev":
				s.previousTrack()
			case "play":
				s.togglePlay()
			case "next":
				s.nextTrack()
			case "viz":
				s.cycleMode()
			case "input":
				s.toggleDesktopInput()
			case "theme":
				s.nextTheme()
			case "shuffle":
				s.toggleShuffle()
			case "repeat":
				s.cycleRepeat()
			case "favorite":
				s.toggleFavorite()
			case "mute":
				s.toggleMute()
			case "speed":
				s.cyclePlaybackSpeed()
			case "recent":
				s.showRecentView()
			case "favs":
				s.showFavoritesView()
			}
			return true
		}
	}
	return false
}

func (s *appState) handleDrop(drop uintptr) {
	defer procDragFinish.Call(drop)
	count, _, _ := procDragQueryFileW.Call(drop, ^uintptr(0), 0, 0)
	var tracks []track
	for i := uintptr(0); i < count; i++ {
		var buffer [4096]uint16
		procDragQueryFileW.Call(drop, i, uintptr(unsafe.Pointer(&buffer[0])), uintptr(len(buffer)))
		path := syscall.UTF16ToString(buffer[:])
		if path == "" {
			continue
		}
		if info, err := os.Stat(path); err == nil && info.IsDir() {
			tracks = append(tracks, collectAudioFiles(path)...)
		} else if isAudioFile(path) {
			tracks = append(tracks, makeTrack(path, s.favorites))
		}
	}
	if len(tracks) > 0 {
		sortTracks(tracks)
		s.openPlaylist(tracks, 0)
	}
}

func collectAudioFiles(root string) []track {
	var tracks []track
	entries, err := os.ReadDir(root)
	if err != nil {
		return tracks
	}
	for _, entry := range entries {
		path := filepath.Join(root, entry.Name())
		if entry.IsDir() {
			continue
		}
		if isAudioFile(path) {
			tracks = append(tracks, makeTrack(path, app.favorites))
		}
	}
	sortTracks(tracks)
	return tracks
}

func sortTracks(tracks []track) {
	sort.Slice(tracks, func(i, j int) bool {
		return strings.ToLower(tracks[i].Title) < strings.ToLower(tracks[j].Title)
	})
}

func makeTrack(path string, favorites map[string]bool) track {
	clean := filepath.Clean(path)
	title := strings.TrimSuffix(filepath.Base(clean), filepath.Ext(clean))
	return track{Path: clean, Title: title, Favorite: favorites[clean]}
}

func indexOfPath(tracks []track, path string) int {
	clean := filepath.Clean(path)
	for i, track := range tracks {
		if strings.EqualFold(track.Path, clean) {
			return i
		}
	}
	return -1
}

func isAudioFile(path string) bool {
	switch strings.ToLower(filepath.Ext(path)) {
	case ".wav", ".mp3", ".wma", ".mid", ".midi", ".aiff", ".aif", ".au", ".snd":
		return true
	default:
		return false
	}
}

func (s *appState) addRecent(path string) {
	clean := filepath.Clean(path)
	next := []string{clean}
	for _, item := range s.recent {
		if !strings.EqualFold(item, clean) && len(next) < 10 {
			next = append(next, item)
		}
	}
	s.recent = next
}

func (s *appState) loadSettings() {
	s.favorites = map[string]bool{}
	data, err := os.ReadFile(settingsPath())
	if err != nil {
		return
	}
	var cfg settings
	if json.Unmarshal(data, &cfg) != nil {
		return
	}
	s.mode = cfg.Mode % modeCount
	s.theme = cfg.Theme % themeCount
	s.volume = clampInt(cfg.Volume, 0, 1000)
	if s.volume == 0 {
		s.volume = 800
	}
	s.muted = cfg.Muted
	s.desktopMode = cfg.DesktopInput
	s.desktopAuto = cfg.DesktopAuto
	if cfg.DesktopSensitivity > 0 {
		s.desktopSensitivity = cfg.DesktopSensitivity
	}
	s.desktopDevice = cfg.DesktopDevice
	s.repeat = cfg.Repeat % 3
	s.shuffle = cfg.Shuffle
	s.recent = cfg.Recent
	s.libraryRoot = cfg.LibraryRoot
	s.seenOnboarding = cfg.SeenOnboarding
	s.windowX = cfg.WindowX
	s.windowY = cfg.WindowY
	s.windowW = cfg.WindowW
	s.windowH = cfg.WindowH
	if cfg.PlaybackSpeed > 0 {
		s.playbackSpeed = cfg.PlaybackSpeed
	}
	s.eqBass = cfg.EqBass
	s.eqMid = cfg.EqMid
	s.eqTreble = cfg.EqTreble
	s.customThemes = cfg.CustomThemes
	for _, fav := range cfg.Favorites {
		s.favorites[filepath.Clean(fav)] = true
	}
}

func (s *appState) saveSettings() {
	cfg := settings{
		Mode:               s.mode,
		Theme:              s.theme,
		Volume:             s.volume,
		Muted:              s.muted,
		DesktopInput:       s.desktopMode,
		DesktopAuto:        s.desktopAuto,
		DesktopSensitivity: s.desktopSensitivity,
		DesktopDevice:      s.desktopDevice,
		Repeat:             s.repeat,
		Shuffle:            s.shuffle,
		Recent:             s.recent,
		LibraryRoot:        s.libraryRoot,
		SeenOnboarding:     s.seenOnboarding,
		WindowX:            s.windowX,
		WindowY:            s.windowY,
		WindowW:            s.windowW,
		WindowH:            s.windowH,
		PlaybackSpeed:      s.playbackSpeed,
		EqBass:             s.eqBass,
		EqMid:              s.eqMid,
		EqTreble:           s.eqTreble,
		CustomThemes:       s.customThemes,
	}
	for fav, ok := range s.favorites {
		if ok {
			cfg.Favorites = append(cfg.Favorites, fav)
		}
	}
	sort.Strings(cfg.Favorites)
	data, err := json.MarshalIndent(cfg, "", "  ")
	if err != nil {
		return
	}
	_ = os.MkdirAll(filepath.Dir(settingsPath()), 0755)
	_ = os.WriteFile(settingsPath(), data, 0644)
}

func settingsPath() string {
	base := os.Getenv("APPDATA")
	if base == "" {
		base = "."
	}
	return filepath.Join(base, "MusicVisualizerPro", "settings.json")
}

type palette struct {
	background uintptr
	panel      uintptr
	text       uintptr
	dim        uintptr
	accent     uintptr
	accent2    uintptr
}

func currentPalette() palette {
	return paletteFor(app.theme)
}

func paletteFor(theme theme) palette {
	if theme >= themeCustomBase {
		idx := int(theme - themeCustomBase)
		if idx >= 0 && idx < len(app.customThemes) {
			return paletteFromCustom(app.customThemes[idx])
		}
	}
	switch theme {
	case themeLava:
		return palette{background: rgb(18, 8, 6), panel: rgb(58, 23, 18), text: rgb(255, 238, 220), dim: rgb(220, 145, 110), accent: rgb(255, 92, 40), accent2: rgb(255, 190, 40)}
	case themeCyberpunk:
		return palette{background: rgb(11, 8, 25), panel: rgb(36, 20, 65), text: rgb(245, 236, 255), dim: rgb(192, 135, 255), accent: rgb(255, 56, 188), accent2: rgb(55, 235, 255)}
	case themeOcean:
		return palette{background: rgb(4, 18, 28), panel: rgb(10, 48, 68), text: rgb(224, 248, 255), dim: rgb(112, 190, 215), accent: rgb(54, 210, 235), accent2: rgb(88, 245, 178)}
	default:
		return palette{background: rgb(10, 12, 22), panel: rgb(26, 32, 51), text: rgb(245, 247, 255), dim: rgb(170, 180, 205), accent: rgb(80, 210, 255), accent2: rgb(185, 90, 255)}
	}
}

func playLabel() string {
	if app.playing {
		return "Pause"
	}
	return "Play"
}

func inputLabel() string {
	if app.desktopMode {
		return "Input On"
	}
	return "Input"
}

func themeName(theme theme) string {
	if theme >= themeCustomBase {
		idx := int(theme - themeCustomBase)
		if idx >= 0 && idx < len(app.customThemes) {
			return app.customThemes[idx].Name
		}
		return "Custom"
	}
	switch theme {
	case themeLava:
		return "Lava"
	case themeCyberpunk:
		return "Cyberpunk"
	case themeOcean:
		return "Ocean"
	default:
		return "Neon"
	}
}

func repeatName(mode repeatMode) string {
	switch mode {
	case repeatOne:
		return "One"
	case repeatAll:
		return "All"
	default:
		return "Off"
	}
}

func sleepText(minutes int) string {
	if minutes == 0 {
		return "Off"
	}
	return fmt.Sprintf("%dm", minutes)
}

func pointInRect(x, y int32, r rect) bool {
	return x >= r.left && x <= r.right && y >= r.top && y <= r.bottom
}

func truncate(text string, maxLen int) string {
	if len(text) <= maxLen {
		return text
	}
	if maxLen <= 3 {
		return text[:maxLen]
	}
	return text[:maxLen-3] + "..."
}

func hashPath(path string) uint32 {
	var hash uint32 = 2166136261
	for _, b := range []byte(strings.ToLower(path)) {
		hash ^= uint32(b)
		hash *= 16777619
	}
	return hash
}

func writeSnapshot(path string, bars []float64, mode visualMode, theme theme) error {
	const width = 900
	const height = 500
	palette := paletteFor(theme)
	bgR, bgG, bgB := colorParts(palette.background)
	accentR, accentG, accentB := colorParts(palette.accent)
	var out strings.Builder
	out.WriteString(fmt.Sprintf("P3\n%d %d\n255\n", width, height))
	for y := 0; y < height; y++ {
		for x := 0; x < width; x++ {
			r, g, b := bgR, bgG, bgB
			index := x * len(bars) / width
			barHeight := int(clamp(bars[index], 0, 1) * float64(height-80))
			switch mode {
			case modeHalo, modeTunnel, modeParticles:
				dx := float64(x - width/2)
				dy := float64(y - height/2)
				dist := math.Sqrt(dx*dx + dy*dy)
				angle := math.Atan2(dy, dx) + math.Pi
				idx := int(angle / (math.Pi * 2) * float64(len(bars)))
				limit := 80 + bars[idx%len(bars)]*180
				if dist > 90 && dist < limit {
					r, g, b = accentR, accentG, accentB
				}
			default:
				if y > height-40-barHeight && y < height-40 {
					r, g, b = accentR, accentG, accentB
				}
			}
			out.WriteString(fmt.Sprintf("%d %d %d ", r, g, b))
		}
		out.WriteByte('\n')
	}
	return os.WriteFile(path, []byte(out.String()), 0644)
}

func colorParts(color uintptr) (int, int, int) {
	return int(color & 0xff), int((color >> 8) & 0xff), int((color >> 16) & 0xff)
}

func clampInt(value, low, high int) int {
	if value < low {
		return low
	}
	if value > high {
		return high
	}
	return value
}

func (s *appState) seekFromPoint(x, y int32) bool {
	if s.filePath == "" || s.duration <= 0 {
		return false
	}
	var bounds rect
	procGetClientRect.Call(s.hwnd, uintptr(unsafe.Pointer(&bounds)))
	bar := progressRect(bounds.right-bounds.left, bounds.bottom-bounds.top)
	if y < bar.top-12 || y > bar.bottom+24 {
		return false
	}
	progress := clamp(float64(x-bar.left)/float64(bar.right-bar.left), 0, 1)
	pos := time.Duration(progress * float64(s.duration))
	s.dragPosition = pos
	s.seekTo(pos, s.playing)
	return true
}

func progressRect(width, height int32) rect {
	return rect{
		left:   28,
		top:    height - 82,
		right:  width - 28,
		bottom: height - 68,
	}
}

func mousePoint(lParam uintptr) (int32, int32) {
	x := int16(lParam & 0xffff)
	y := int16((lParam >> 16) & 0xffff)
	return int32(x), int32(y)
}

func line(hdc uintptr, x1, y1, x2, y2 int32, color uintptr, width int32) {
	pen, _, _ := procCreatePen.Call(0, uintptr(width), color)
	if pen == 0 {
		return
	}
	old, _, _ := procSelectObject.Call(hdc, pen)
	procMoveToEx.Call(hdc, uintptr(x1), uintptr(y1), 0)
	procLineTo.Call(hdc, uintptr(x2), uintptr(y2))
	procSelectObject.Call(hdc, old)
	procDeleteObject.Call(pen)
}

func ellipse(hdc uintptr, left, top, right, bottom int32, color uintptr) {
	brush, _, _ := procCreateSolidBrush.Call(color)
	if brush == 0 {
		return
	}
	old, _, _ := procSelectObject.Call(hdc, brush)
	procEllipse.Call(hdc, uintptr(left), uintptr(top), uintptr(right), uintptr(bottom))
	procSelectObject.Call(hdc, old)
	procDeleteObject.Call(brush)
}

func gradientColor(index, total int, alpha byte) uintptr {
	if total <= 1 {
		return rgb(80, 210, alpha)
	}
	t := float64(index) / float64(total-1)
	r := byte(60 + 170*math.Pow(t, 1.2))
	g := byte(210 - 90*t)
	b := byte(255 - 115*t)
	return rgb(r, g, b)
}

func bandGradientColor(index, total int, bars []float64) uintptr {
	bass, mid, treble := visual.SplitBands(bars)
	t := float64(index) / float64(max(1, total-1))
	r := byte(40 + bass*200 + t*30)
	g := byte(40 + mid*200 + t*20)
	b := byte(40 + treble*200 + (1-t)*40)
	return rgb(r, g, b)
}

func dimColor(color uintptr, factor float64) uintptr {
	r := byte(float64(color&0xff) * factor)
	g := byte(float64((color>>8)&0xff) * factor)
	b := byte(float64((color>>16)&0xff) * factor)
	return rgb(r, g, b)
}

func modeName(mode visualMode) string {
	switch mode {
	case modeMirror:
		return "Mirror"
	case modeBlocks:
		return "Blocks"
	case modeWave:
		return "Wave"
	case modeHalo:
		return "Halo"
	case modeSpectrum:
		return "Spectrum"
	case modeFire:
		return "Fire"
	case modeParticles:
		return "Particles"
	case modeTunnel:
		return "Tunnel"
	case modePlasma:
		return "Plasma"
	default:
		return "Classic"
	}
}

func openTrack(path string) error {
	closeTrack()
	if err := mciSend(fmt.Sprintf(`open "%s" alias musicvisualizer_track`, escapeMCI(path))); err != nil {
		return err
	}
	if err := mciSend("set musicvisualizer_track time format milliseconds"); err != nil {
		closeTrack()
		return err
	}
	return nil
}

func playTrackFrom(pos time.Duration) error {
	return mciSendNotify(fmt.Sprintf("play musicvisualizer_track from %d notify", durationMS(pos)), app.hwnd)
}

func pauseTrack() error {
	return mciSend("pause musicvisualizer_track")
}

func stopTrack() error {
	return mciSend("stop musicvisualizer_track")
}

func closeTrack() {
	_ = mciSend("stop musicvisualizer_track")
	_ = mciSend("close musicvisualizer_track")
}

func mciSend(command string) error {
	commandPtr, err := syscall.UTF16PtrFromString(command)
	if err != nil {
		return err
	}
	ret, _, _ := procMCISendStringW.Call(uintptr(unsafe.Pointer(commandPtr)), 0, 0, 0)
	if ret == 0 {
		return nil
	}
	return fmt.Errorf("%s", mciError(ret))
}

func mciSendNotify(command string, hwnd uintptr) error {
	commandPtr, err := syscall.UTF16PtrFromString(command)
	if err != nil {
		return err
	}
	ret, _, _ := procMCISendStringW.Call(uintptr(unsafe.Pointer(commandPtr)), 0, 0, hwnd)
	if ret == 0 {
		return nil
	}
	return fmt.Errorf("%s", mciError(ret))
}

func trackDuration() (time.Duration, error) {
	var buffer [64]uint16
	command, _ := syscall.UTF16PtrFromString("status musicvisualizer_track length")
	ret, _, _ := procMCISendStringW.Call(uintptr(unsafe.Pointer(command)), uintptr(unsafe.Pointer(&buffer[0])), uintptr(len(buffer)), 0)
	if ret != 0 {
		return 0, fmt.Errorf("%s", mciError(ret))
	}
	var ms int64
	_, err := fmt.Sscanf(syscall.UTF16ToString(buffer[:]), "%d", &ms)
	if err != nil {
		return 0, err
	}
	return time.Duration(ms) * time.Millisecond, nil
}

func mciError(code uintptr) string {
	var buffer [256]uint16
	ret, _, _ := procMCIGetErrorStringW.Call(code, uintptr(unsafe.Pointer(&buffer[0])), uintptr(len(buffer)))
	if ret == 0 {
		return fmt.Sprintf("MCI error %d", code)
	}
	return syscall.UTF16ToString(buffer[:])
}

func escapeMCI(path string) string {
	return strings.ReplaceAll(path, `"`, `""`)
}

func invalidate() {
	if app.hwnd != 0 {
		procInvalidateRect.Call(app.hwnd, 0, 1)
	}
}

func idleBars() []float64 {
	bars := make([]float64, barCount)
	now := float64(time.Now().UnixMilli()) / 280
	for i := range bars {
		wave := math.Sin(now+float64(i)*0.45)*0.5 + 0.5
		bars[i] = 0.1 + wave*0.18
	}
	return bars
}

func fill(hdc uintptr, r rect, color uintptr) {
	brush, _, _ := procCreateSolidBrush.Call(color)
	if brush == 0 {
		return
	}
	procFillRect.Call(hdc, uintptr(unsafe.Pointer(&r)), brush)
	procDeleteObject.Call(brush)
}

func textOut(hdc uintptr, x, y int32, text string) {
	chars, err := syscall.UTF16FromString(text)
	if err != nil || len(chars) == 0 {
		return
	}
	procTextOutW.Call(hdc, uintptr(x), uintptr(y), uintptr(unsafe.Pointer(&chars[0])), uintptr(len(chars)-1))
}

func showMessage(hwnd uintptr, title, body string, flags uintptr) {
	titlePtr, _ := syscall.UTF16PtrFromString(title)
	bodyPtr, _ := syscall.UTF16PtrFromString(body)
	procMessageBoxW.Call(hwnd, uintptr(unsafe.Pointer(bodyPtr)), uintptr(unsafe.Pointer(titlePtr)), flags)
}

func durationText(duration time.Duration) string {
	if duration < 0 {
		duration = 0
	}
	totalSeconds := int(duration.Seconds() + 0.5)
	minutes := totalSeconds / 60
	seconds := totalSeconds % 60
	return fmt.Sprintf("%d:%02d", minutes, seconds)
}

func durationMS(duration time.Duration) int64 {
	if duration < 0 {
		return 0
	}
	return int64(duration / time.Millisecond)
}

func utf16WithNULs(s string) []uint16 {
	if !strings.HasSuffix(s, "\x00") {
		s += "\x00"
	}
	return utf16.Encode([]rune(s))
}

func rgb(r, g, b byte) uintptr {
	return uintptr(r) | uintptr(g)<<8 | uintptr(b)<<16
}

func clamp(value, low, high float64) float64 {
	if value < low {
		return low
	}
	if value > high {
		return high
	}
	return value
}

func clampDuration(value, low, high time.Duration) time.Duration {
	if value < low {
		return low
	}
	if value > high {
		return high
	}
	return value
}
